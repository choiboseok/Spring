package com.future.my.pro.dao;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Mapper;

import com.future.my.pro.vo.ProVO;

@Mapper
public interface IProDAO {
	// 어항 출력
	public ArrayList<ProVO> fishInfo(ProVO proVO);
	// 여과기 출력
	public ArrayList<ProVO> cleanInfo(ProVO proVO);
	// 히터기 출력
	public ArrayList<ProVO> heatInfo(ProVO proVO);
	// 사료/영양제 출력
	public ArrayList<ProVO> foodInfo(ProVO proVO);
	// 소켓/조명 출력
	public ArrayList<ProVO> lightInfo(ProVO proVO);
	// 육지 출력
	public ArrayList<ProVO> shoreInfo(ProVO proVO);
	
}
