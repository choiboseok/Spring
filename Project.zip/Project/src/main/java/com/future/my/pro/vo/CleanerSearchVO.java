package com.future.my.pro.vo;

public class CleanerSearchVO {
	private String cleanerNo;            /* 여과기 상품번호 */
	private String cleanerTitle;         /* 여과기 상품명 */
	private String cleanerHref;          /* 여과기 상품링크 */
	private String cleanerImg;           /* 여과기 상품 이미지 */
	private String cleanerPrice;         /* 여과기 상품가격 */
	private String cleanerType;          /* 여과기 종류 */
	
	public CleanerSearchVO() {
	}
	
	@Override
	public String toString() {
		return "CleanerSearchVO [cleanerNo=" + cleanerNo + ", cleanerTitle=" + cleanerTitle + ", cleanerHref="
				+ cleanerHref + ", cleanerImg=" + cleanerImg + ", cleanerPrice=" + cleanerPrice + ", cleanerType="
				+ cleanerType + "]";
	}
	
	public String getCleanerNo() {
		return cleanerNo;
	}
	public void setCleanerNo(String cleanerNo) {
		this.cleanerNo = cleanerNo;
	}
	public String getCleanerTitle() {
		return cleanerTitle;
	}
	public void setCleanerTitle(String cleanerTitle) {
		this.cleanerTitle = cleanerTitle;
	}
	public String getCleanerHref() {
		return cleanerHref;
	}
	public void setCleanerHref(String cleanerHref) {
		this.cleanerHref = cleanerHref;
	}
	public String getCleanerImg() {
		return cleanerImg;
	}
	public void setCleanerImg(String cleanerImg) {
		this.cleanerImg = cleanerImg;
	}
	public String getCleanerPrice() {
		return cleanerPrice;
	}
	public void setCleanerPrice(String cleanerPrice) {
		this.cleanerPrice = cleanerPrice;
	}
	public String getCleanerType() {
		return cleanerType;
	}
	public void setCleanerType(String cleanerType) {
		this.cleanerType = cleanerType;
	}
	
	
}
