package com.future.my.pro.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.future.my.pro.dao.IProDAO;
import com.future.my.pro.vo.ProVO;

@Service
public class ProService {
	
	@Autowired
	IProDAO dao;
	// 어항 출력
	public ArrayList<ProVO> fishInfo(ProVO proVO){
		return dao.fishInfo(proVO);
	}
	// 여과기 출력
	public ArrayList<ProVO> cleanInfo(ProVO proVO){
		return dao.cleanInfo(proVO);
	}
	// 히터기 출력
	public ArrayList<ProVO> heatInfo(ProVO proVO){
		return dao.heatInfo(proVO);
	}
	// 사료/영양제 출력
	public ArrayList<ProVO> foodInfo(ProVO proVO){
		return dao.foodInfo(proVO);
	}
	// 소켓/조명 출력
	public ArrayList<ProVO> lightInfo(ProVO proVO){
		return dao.lightInfo(proVO);
	}
	// 육지 출력
	public ArrayList<ProVO> shoreInfo(ProVO proVO){
		return dao.shoreInfo(proVO);
	}
}
