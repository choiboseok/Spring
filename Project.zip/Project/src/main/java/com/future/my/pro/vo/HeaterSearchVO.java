package com.future.my.pro.vo;

public class HeaterSearchVO {
	private String heaterNo;            /* 히터기 상품번호 */
	private String heaterTitle;         /* 히터기 상품명 */
	private String heaterHref;          /* 히터기 상품링크 */
	private String heaterImg;           /* 히터기 상품 이미지 */
	private String heaterPrice;         /* 히터기 상품가격 */
	private String heaterType;          /* 히터기 종류 */
	
	public HeaterSearchVO() {
	}
	
	@Override
	public String toString() {
		return "HeaterSearchVO [heaterNo=" + heaterNo + ", heaterTitle=" + heaterTitle + ", heaterHref=" + heaterHref
				+ ", heaterImg=" + heaterImg + ", heaterPrice=" + heaterPrice + ", heaterType=" + heaterType + "]";
	}
	
	public String getHeaterNo() {
		return heaterNo;
	}
	public void setHeaterNo(String heaterNo) {
		this.heaterNo = heaterNo;
	}
	public String getHeaterTitle() {
		return heaterTitle;
	}
	public void setHeaterTitle(String heaterTitle) {
		this.heaterTitle = heaterTitle;
	}
	public String getHeaterHref() {
		return heaterHref;
	}
	public void setHeaterHref(String heaterHref) {
		this.heaterHref = heaterHref;
	}
	public String getHeaterImg() {
		return heaterImg;
	}
	public void setHeaterImg(String heaterImg) {
		this.heaterImg = heaterImg;
	}
	public String getHeaterPrice() {
		return heaterPrice;
	}
	public void setHeaterPrice(String heaterPrice) {
		this.heaterPrice = heaterPrice;
	}
	public String getHeaterType() {
		return heaterType;
	}
	public void setHeaterType(String heaterType) {
		this.heaterType = heaterType;
	}
	
	
}
