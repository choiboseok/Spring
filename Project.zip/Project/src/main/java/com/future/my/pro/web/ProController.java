package com.future.my.pro.web;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.future.my.free.vo.FreeBoardSearchVO;
import com.future.my.free.vo.FreeBoardVO;
import com.future.my.pro.service.ProService;
import com.future.my.pro.vo.CleanerSearchVO;
import com.future.my.pro.vo.FishtankCheckVO;
import com.future.my.pro.vo.FishtankSearchVO;
import com.future.my.pro.vo.ProVO;
import com.future.my.pro.vo.ProjectVO;

@Controller
public class ProController {
	@Autowired
	ProService proService;
	
	// 메인 페이지(리스트 없음)
	@RequestMapping(value = "/")
	public String home(ProjectVO searchVO, Model model) {
		ArrayList<ProjectVO> categoryList = proService.categoryInfo(searchVO);
		model.addAttribute("categoryList", categoryList);
		ArrayList<ProjectVO> contentList = proService.contentInfo(searchVO);
		model.addAttribute("contentList", contentList);
		
		return "home";
	}
	
	// 어항 상품 리스트
	@RequestMapping("/fishList")
	public String fishTank( Model model, @ModelAttribute("searchVO") FishtankSearchVO searchVO) {
		ArrayList<ProVO> fishList = proService.fishInfo(searchVO);
		model.addAttribute("fishList", fishList);
		
		return "pro/fishtank";
	}
//	
//	// 어항 체크박스 리스트
//	@RequestMapping("/fishtankList")
//	public String fishTankCheck(FishtankCheckVO fishtankcheckVO, Model model) {
//		ArrayList<FishtankCheckVO> fishtankcheckList = proService.fishtankCheckInfo(fishtankcheckVO);
//		model.addAttribute("fishtankcheckList", fishtankcheckList);
//		
//		return "pro/fishtank";
//	}
//		
//	// 어항 옵션 선택 리스트
//	@RequestMapping("/fishtankSearchList")
//	public String fishtankSearch(Model model, @ModelAttribute FishtankSearchVO fishtanksearchVO) {
//		ArrayList<String> type = fishtanksearchVO.getFishtankType();
//		for(String fishtankType : type) {
//			proService.fishtankSearchInfo(fishtankType);
//		}
//		
//		return "pro/fishtank";
//	}
		
	// 여과기 상품 리스트
	@RequestMapping("/cleanList")
	public String cleaner(Model model, ProVO proVO) {
		ArrayList<ProVO> cleanList = proService.cleanInfo(proVO);
		model.addAttribute("cleanList", cleanList);
		
		return "pro/cleaner";
	}
	// 여과기 옵션 선택 리스트
	@RequestMapping("/cleanSearchList")
	public String cleanerSearch(Model model, @ModelAttribute CleanerSearchVO cleanersearchVO) {
		ArrayList<CleanerSearchVO> cleanList = proService.cleanerSearchInfo(cleanersearchVO);
		model.addAttribute("cleanList", cleanList);
		
		return "pro/cleaner";
	}
	
	
	// 히터기 상품 리스트
	@RequestMapping("/heatList")
	public String heater(ProVO proVO, Model model) {
		ArrayList<ProVO> heatList = proService.heatInfo(proVO);
		model.addAttribute("heatList", heatList);
		
		return "pro/heater";
	}
	
	// 사료/영양제 상품 리스트
	@RequestMapping("/foodList")
	public String food(ProVO proVO, Model model) {
		ArrayList<ProVO> foodList = proService.foodInfo(proVO);
		model.addAttribute("foodList", foodList);
		
		return "pro/food";
	}
	
	// 소켓/조명 상품 리스트
	@RequestMapping("/lightList")
	public String light(ProVO proVO, Model model) {
		ArrayList<ProVO> lightList = proService.lightInfo(proVO);
		model.addAttribute("lightList", lightList);
		
		return "pro/light";
	}
	
	// 육지 상품 리스트
	@RequestMapping("/shoreList")
	public String shore(ProVO proVO, Model model) {
		ArrayList<ProVO> shoreList = proService.shoreInfo(proVO);
		model.addAttribute("shoreList", shoreList);
		
		return "pro/shore";
	}
}
