package com.future.my.pro.web;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.future.my.pro.service.ProService;
import com.future.my.pro.vo.ProVO;

@Controller
public class ProController {
	@Autowired
	ProService proService;
	
	@RequestMapping(value = "/")
	public String home(ProVO proVO, Model model) {
//		ArrayList<ProVO> fishList = proService.fishInfo(proVO);
//		model.addAttribute("fishList", fishList);
		
		return "home";
	}
	
	@RequestMapping("/fishList")
	public String fishTank(ProVO proVO, Model model) {
		ArrayList<ProVO> fishList = proService.fishInfo(proVO);
		model.addAttribute("fishList", fishList);
		
		return "pro/fishtank";
	}
	
	@RequestMapping("/cleanList")
	public String cleaner(ProVO proVO, Model model) {
		ArrayList<ProVO> cleanList = proService.cleanInfo(proVO);
		model.addAttribute("cleanList", cleanList);
		
		return "pro/cleaner";
	}
	
	@RequestMapping("/heatList")
	public String heater(ProVO proVO, Model model) {
		ArrayList<ProVO> heatList = proService.heatInfo(proVO);
		model.addAttribute("heatList", heatList);
		
		return "pro/heater";
	}
	
	@RequestMapping("/foodList")
	public String food(ProVO proVO, Model model) {
		ArrayList<ProVO> foodList = proService.foodInfo(proVO);
		model.addAttribute("foodList", foodList);
		
		return "pro/food";
	}
	
	@RequestMapping("/lightList")
	public String light(ProVO proVO, Model model) {
		ArrayList<ProVO> lightList = proService.lightInfo(proVO);
		model.addAttribute("lightList", lightList);
		
		return "pro/light";
	}
	
	@RequestMapping("/shoreList")
	public String shore(ProVO proVO, Model model) {
		ArrayList<ProVO> shoreList = proService.shoreInfo(proVO);
		model.addAttribute("shoreList", shoreList);
		
		return "pro/shore";
	}
	
	
}
