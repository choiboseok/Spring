package com.future.my.pro.vo;

public class LightSearchVO {
	private String lightNo;          /* 조명 상품번호 */
	private String lightTitle;       /* 조명 상품이름 */
	private String lightHref;        /* 조명 상품링크 */
	private String lightImg;         /* 조명 상품이미지 */
	private String lightPrice;       /* 조명 상품가격 */
	private String lightType;        /* 조명 상품종류 */
	
	public LightSearchVO() {
	}
	
	@Override
	public String toString() {
		return "LightSearchVO [lightNo=" + lightNo + ", lightTitle=" + lightTitle + ", lightHref=" + lightHref
				+ ", lightImg=" + lightImg + ", lightPrice=" + lightPrice + ", lightType=" + lightType + "]";
	}
	
	public String getLightNo() {
		return lightNo;
	}
	public void setLightNo(String lightNo) {
		this.lightNo = lightNo;
	}
	public String getLightTitle() {
		return lightTitle;
	}
	public void setLightTitle(String lightTitle) {
		this.lightTitle = lightTitle;
	}
	public String getLightHref() {
		return lightHref;
	}
	public void setLightHref(String lightHref) {
		this.lightHref = lightHref;
	}
	public String getLightImg() {
		return lightImg;
	}
	public void setLightImg(String lightImg) {
		this.lightImg = lightImg;
	}
	public String getLightPrice() {
		return lightPrice;
	}
	public void setLightPrice(String lightPrice) {
		this.lightPrice = lightPrice;
	}
	public String getLightType() {
		return lightType;
	}
	public void setLightType(String lightType) {
		this.lightType = lightType;
	}
	
}
