package com.future.my.pro.vo;

import java.util.ArrayList;

import com.future.my.common.vo.PagingVO;

public class FishtankSearchVO extends PagingVO  {
	private String fishtankNo;            /* 어항 상품번호 */
	private String fishtankTitle;         /* 어항 상품명 */
	private String fishtankHref;          /* 어항 상품링크 */
	private String fishtankImg;           /* 어항 상품 이미지 */
	private String fishtankPrice;         /* 어항 상품가격 */
	private ArrayList<String> fishtankType;           /* 어항 종류 */
	private ArrayList<String> fishtankWidth;         /* 어항 가로 */
	private ArrayList<String> fishtankLength;        /* 어항 세로 */
	private ArrayList<String> fishtankHeight;        /* 어항 높이 */
	public String getFishtankNo() {
		return fishtankNo;
	}
	public void setFishtankNo(String fishtankNo) {
		this.fishtankNo = fishtankNo;
	}
	public String getFishtankTitle() {
		return fishtankTitle;
	}
	public void setFishtankTitle(String fishtankTitle) {
		this.fishtankTitle = fishtankTitle;
	}
	public String getFishtankHref() {
		return fishtankHref;
	}
	public void setFishtankHref(String fishtankHref) {
		this.fishtankHref = fishtankHref;
	}
	public String getFishtankImg() {
		return fishtankImg;
	}
	public void setFishtankImg(String fishtankImg) {
		this.fishtankImg = fishtankImg;
	}
	public String getFishtankPrice() {
		return fishtankPrice;
	}
	public void setFishtankPrice(String fishtankPrice) {
		this.fishtankPrice = fishtankPrice;
	}
	public ArrayList<String> getFishtankType() {
		return fishtankType;
	}
	public void setFishtankType(ArrayList<String> fishtankType) {
		this.fishtankType = fishtankType;
	}
	public ArrayList<String> getFishtankWidth() {
		return fishtankWidth;
	}
	public void setFishtankWidth(ArrayList<String> fishtankWidth) {
		this.fishtankWidth = fishtankWidth;
	}
	public ArrayList<String> getFishtankLength() {
		return fishtankLength;
	}
	public void setFishtankLength(ArrayList<String> fishtankLength) {
		this.fishtankLength = fishtankLength;
	}
	public ArrayList<String> getFishtankHeight() {
		return fishtankHeight;
	}
	public void setFishtankHeight(ArrayList<String> fishtankHeight) {
		this.fishtankHeight = fishtankHeight;
	}
	@Override
	public String toString() {
		return "FishtankSearchVO [fishtankNo=" + fishtankNo + ", fishtankTitle=" + fishtankTitle + ", fishtankHref="
				+ fishtankHref + ", fishtankImg=" + fishtankImg + ", fishtankPrice=" + fishtankPrice + ", fishtankType="
				+ fishtankType + ", fishtankWidth=" + fishtankWidth + ", fishtankLength=" + fishtankLength
				+ ", fishtankHeight=" + fishtankHeight + "]";
	}
	public FishtankSearchVO() {
	}
	
	
	
	
}
