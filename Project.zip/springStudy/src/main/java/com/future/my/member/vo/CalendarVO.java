package com.future.my.member.vo;

public class CalendarVO {
	private int calNo;
	private String calTitle;
	private String calStart;
	private String calEnd;
	private String calBgColor;
	private String memId;
	private String uesYn;
	
	public CalendarVO() {
	}

	@Override
	public String toString() {
		return "CalendarVO [calNo=" + calNo + ", calTitle=" + calTitle + ", calStart=" + calStart + ", calEnd=" + calEnd
				+ ", calBgColor=" + calBgColor + ", memId=" + memId + ", uesYn=" + uesYn + "]";
	}

	public int getCalNo() {return calNo;}
	public void setCalNo(int calNo) {this.calNo = calNo;}

	public String getCalTitle() {return calTitle;}
	public void setCalTitle(String calTitle) {this.calTitle = calTitle;}

	public String getCalStart() {return calStart;}
	public void setCalStart(String calStart) {this.calStart = calStart;}

	public String getCalEnd() {return calEnd;}
	public void setCalEnd(String calEnd) {this.calEnd = calEnd;}

	public String getCalBgColor() {return calBgColor;}
	public void setCalBgColor(String calBgColor) {this.calBgColor = calBgColor;}

	public String getMemId() {return memId;}
	public void setMemId(String memId) {this.memId = memId;}

	public String getUesYn() {return uesYn;}
	public void setUesYn(String uesYn) {this.uesYn = uesYn;}
}
