package com.future.my.member.dao;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Mapper;

import com.future.my.member.vo.CalendarVO;
import com.future.my.member.vo.MemberVO;

@Mapper
public interface IMemberDAO {
	// mapper xml의 id와 매핑됨.
	// input parameterType
	// output resultType
	public int registMember(MemberVO vo);
	
	public MemberVO loginMember(MemberVO vo);
	//프로필 이미지 수정
	public int profileUpload(MemberVO vo);
	// 일정 조회
	public ArrayList<CalendarVO> getCalendarList(String memId);
	// 일정저장
	public int calendarInsert(CalendarVO vo);
	
}
