package com.future.my.pro.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.future.my.pro.dao.IProDAO;
//import com.future.my.pro.vo.FishtankSearchVO;
import com.future.my.pro.vo.ProjectVO;

@Service
public class ProService {
	
	@Autowired
	IProDAO dao;
	// 어항 출력
	/*
	public ArrayList<ProVO> fishInfo(FishtankSearchVO searchVO){
		//1.전체 건수 조회
		int totalRowCount = dao.fishCnt(searchVO);
		searchVO.setTotalRowCount(totalRowCount);
		//2.검색 조건으로 검색된 전체 건수를 기준으로 paing 세팅
		searchVO.pageSetting();
		//3.currrent에 해당하는 firstRow ~ lastRow 까지 목록 조회결과 리턴
		return dao.fishInfo(searchVO);
	}
	*/
	
	// 상품 출력
	public ArrayList<ProjectVO> contentList(ProjectVO searchVO){
		return dao.contentList(searchVO);
	}
	
}
