package com.future.my.pro.vo;

public class FoodSearchVO {
	private String foodNo;           /* 사료 상품번호 */
	private String foodTitle;        /* 사료 상품제목 */
	private String foodHref;         /* 사료 상품링크 */
	private String foodImg;          /* 사료 상품이미지 */
	private String foodPrice;        /* 사료 상품가격 */
	private String foodType;         /* 사료 상품종류 */
	
	public FoodSearchVO() {
	}
	
	@Override
	public String toString() {
		return "FoodSearchVO [foodNo=" + foodNo + ", foodTitle=" + foodTitle + ", foodHref=" + foodHref + ", foodImg="
				+ foodImg + ", foodPrice=" + foodPrice + ", foodType=" + foodType + "]";
	}
	public String getFoodNo() {
		return foodNo;
	}
	public void setFoodNo(String foodNo) {
		this.foodNo = foodNo;
	}
	public String getFoodTitle() {
		return foodTitle;
	}
	public void setFoodTitle(String foodTitle) {
		this.foodTitle = foodTitle;
	}
	public String getFoodHref() {
		return foodHref;
	}
	public void setFoodHref(String foodHref) {
		this.foodHref = foodHref;
	}
	public String getFoodImg() {
		return foodImg;
	}
	public void setFoodImg(String foodImg) {
		this.foodImg = foodImg;
	}
	public String getFoodPrice() {
		return foodPrice;
	}
	public void setFoodPrice(String foodPrice) {
		this.foodPrice = foodPrice;
	}
	public String getFoodType() {
		return foodType;
	}
	public void setFoodType(String foodType) {
		this.foodType = foodType;
	}
	
	
	
}
