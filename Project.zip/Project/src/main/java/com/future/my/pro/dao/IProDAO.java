package com.future.my.pro.dao;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Mapper;

import com.future.my.pro.vo.CleanerSearchVO;
import com.future.my.pro.vo.FishtankCheckVO;
import com.future.my.pro.vo.FishtankSearchVO;
import com.future.my.pro.vo.FoodSearchVO;
import com.future.my.pro.vo.HeaterSearchVO;
import com.future.my.pro.vo.LightSearchVO;
import com.future.my.pro.vo.ProVO;
import com.future.my.pro.vo.ProjectVO;
import com.future.my.pro.vo.ShoreSearchVO;

@Mapper
public interface IProDAO {
	
	// 카테고리 출력
	public ArrayList<ProjectVO> categoryInfo(ProjectVO searchVO);
	// 상품 출력
	public ArrayList<ProjectVO> contentInfo(ProjectVO searchVO); 
	
	
	// 어항 출력
	public int fishCnt(FishtankSearchVO searchVO);
	public ArrayList<ProVO> fishInfo(FishtankSearchVO searchVO);
	// 여과기 출력
	public ArrayList<ProVO> cleanInfo(ProVO proVO);
	// 히터기 출력
	public ArrayList<ProVO> heatInfo(ProVO proVO);
	// 사료/영양제 출력
	public ArrayList<ProVO> foodInfo(ProVO proVO);
	// 소켓/조명 출력
	public ArrayList<ProVO> lightInfo(ProVO proVO);
	// 육지 출력
	public ArrayList<ProVO> shoreInfo(ProVO proVO);
	
	// 어항 옵션 선택 후 상품 출력
	public ArrayList<FishtankSearchVO> fishtankSearchInfo(FishtankSearchVO fishtanksearchVO);
	// 여과기 옵션 선택 후 상품 출력
	public ArrayList<CleanerSearchVO> cleanerSearchInfo(CleanerSearchVO cleansearchVO);
	// 히터기 옵션 선택 후 상품 출력
	public ArrayList<HeaterSearchVO> heaterSearchInfo(HeaterSearchVO heatersearchVO);
	// 사료 옵션 선택 후 상품 출력
	public ArrayList<FoodSearchVO> foodSearchInfo(FoodSearchVO foodsearchVO);
	// 조명 옵션 선택 후 상품 출력
	public ArrayList<LightSearchVO> lightSearchInfo(LightSearchVO lightsearchVO);
	// 육지 옵션 선택 후 상품 출력
	public ArrayList<ShoreSearchVO> shoreSearchInfo(ShoreSearchVO shoresearchVO);
	
	// 어항 체크 박스 출력
	public ArrayList<FishtankCheckVO> fishtankCheckInfo(FishtankCheckVO fishtankcheckVO);
}
