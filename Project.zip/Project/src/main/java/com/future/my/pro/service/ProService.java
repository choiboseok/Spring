package com.future.my.pro.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.future.my.pro.dao.IProDAO;
import com.future.my.pro.vo.CleanerSearchVO;
import com.future.my.pro.vo.FishtankCheckVO;
import com.future.my.pro.vo.FishtankSearchVO;
import com.future.my.pro.vo.FoodSearchVO;
import com.future.my.pro.vo.HeaterSearchVO;
import com.future.my.pro.vo.LightSearchVO;
import com.future.my.pro.vo.ProVO;
import com.future.my.pro.vo.ProjectVO;
import com.future.my.pro.vo.ShoreSearchVO;

@Service
public class ProService {
	
	@Autowired
	IProDAO dao;
	// 어항 출력
	public ArrayList<ProVO> fishInfo(FishtankSearchVO searchVO){
		//1.전체 건수 조회
		int totalRowCount = dao.fishCnt(searchVO);
		searchVO.setTotalRowCount(totalRowCount);
		//2.검색 조건으로 검색된 전체 건수를 기준으로 paing 세팅
		searchVO.pageSetting();
		//3.currrent에 해당하는 firstRow ~ lastRow 까지 목록 조회결과 리턴
		return dao.fishInfo(searchVO);
	}
	
	public ArrayList<ProjectVO> categoryInfo(ProjectVO searchVO){
		return dao.categoryInfo(searchVO);
	}
	
	public ArrayList<ProjectVO> contentInfo(ProjectVO searchVO){
		return dao.contentInfo(searchVO);
	}
	
	
	
	
	// 여과기 출력
	public ArrayList<ProVO> cleanInfo(ProVO proVO){
		return dao.cleanInfo(proVO);
	}
	// 히터기 출력
	public ArrayList<ProVO> heatInfo(ProVO proVO){
		return dao.heatInfo(proVO);
	}
	// 사료/영양제 출력
	public ArrayList<ProVO> foodInfo(ProVO proVO){
		return dao.foodInfo(proVO);
	}
	// 소켓/조명 출력
	public ArrayList<ProVO> lightInfo(ProVO proVO){
		return dao.lightInfo(proVO);
	}
	// 육지 출력
	public ArrayList<ProVO> shoreInfo(ProVO proVO){
		return dao.shoreInfo(proVO);
	}
	
	// 어항 옵션 선택
	public ArrayList<FishtankSearchVO> fishtankSearchInfo(FishtankSearchVO fishtanksearchVO){
		
		
		
		return dao.fishtankSearchInfo(fishtanksearchVO);
	}
	// 여과기 옵션 선택
	public ArrayList<CleanerSearchVO> cleanerSearchInfo(CleanerSearchVO cleanersearchVO){
		return dao.cleanerSearchInfo(cleanersearchVO);
	}
	// 히터기 옵션 선택
	public ArrayList<HeaterSearchVO> HeaterSearchInfo(HeaterSearchVO heatersearchVO){
		return dao.heaterSearchInfo(heatersearchVO);
	}
	
	// 사료 옵션 선택
	public ArrayList<FoodSearchVO> foodSearchInfo(FoodSearchVO foodsearchVO){
		return dao.foodSearchInfo(foodsearchVO);
	}
	// 조명 옵션 선택 
	public ArrayList<LightSearchVO> lightSearchInfo(LightSearchVO lightsearchVO){
		return dao.lightSearchInfo(lightsearchVO);
	}
	// 육지 옵션 선택 
	public ArrayList<ShoreSearchVO> shoreSearchInfo(ShoreSearchVO shoresearchVO){
		return dao.shoreSearchInfo(shoresearchVO);
	}
	
	// 어항 체크 박스 출력
	public ArrayList<FishtankCheckVO> fishtankCheckInfo(FishtankCheckVO fishtankcheckVO){
		return dao.fishtankCheckInfo(fishtankcheckVO);
	}
}
