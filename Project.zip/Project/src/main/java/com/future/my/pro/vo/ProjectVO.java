package com.future.my.pro.vo;

public class ProjectVO {
	private String goodsNO;
	private String goodsCategory;
	private String goodsTitle;
	private String goodsHref;
	private String goodsImg;
	private String goodsPrice;
	private String goodsType;
	public ProjectVO() {
	}
	@Override
	public String toString() {
		return "ProjectVO [goodsNO=" + goodsNO + ", goodsCategory=" + goodsCategory + ", goodsTitle=" + goodsTitle
				+ ", goodsHref=" + goodsHref + ", goodsImg=" + goodsImg + ", goodsPrice=" + goodsPrice + ", goodsType="
				+ goodsType + "]";
	}
	public String getGoodsNO() {
		return goodsNO;
	}
	public void setGoodsNO(String goodsNO) {
		this.goodsNO = goodsNO;
	}
	public String getGoodsCategory() {
		return goodsCategory;
	}
	public void setGoodsCategory(String goodsCategory) {
		this.goodsCategory = goodsCategory;
	}
	public String getGoodsTitle() {
		return goodsTitle;
	}
	public void setGoodsTitle(String goodsTitle) {
		this.goodsTitle = goodsTitle;
	}
	public String getGoodsHref() {
		return goodsHref;
	}
	public void setGoodsHref(String goodsHref) {
		this.goodsHref = goodsHref;
	}
	public String getGoodsImg() {
		return goodsImg;
	}
	public void setGoodsImg(String goodsImg) {
		this.goodsImg = goodsImg;
	}
	public String getGoodsPrice() {
		return goodsPrice;
	}
	public void setGoodsPrice(String goodsPrice) {
		this.goodsPrice = goodsPrice;
	}
	public String getGoodsType() {
		return goodsType;
	}
	public void setGoodsType(String goodsType) {
		this.goodsType = goodsType;
	}
	
	
}
