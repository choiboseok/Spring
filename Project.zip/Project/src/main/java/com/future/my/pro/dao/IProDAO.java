package com.future.my.pro.dao;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Mapper;

import com.future.my.pro.vo.ProjectVO;

@Mapper
public interface IProDAO {
	
	// 상품 출력
	public ArrayList<ProjectVO> contentList(ProjectVO searchVO);
	
	// 어항 출력
//	public int fishCnt(FishtankSearchVO searchVO);
//	public ArrayList<ProVO> fishInfo(FishtankSearchVO searchVO);
}
