package com.future.my.pro.vo;

public class FishtankCheckVO {
	private String type;
	private String width;
	private String length;
	private String height;
	public FishtankCheckVO() {
	}
	@Override
	public String toString() {
		return "FishtankCheckVO [type=" + type + ", width=" + width + ", length=" + length + ", height=" + height + "]";
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getWidth() {
		return width;
	}
	public void setWidth(String width) {
		this.width = width;
	}
	public String getLength() {
		return length;
	}
	public void setLength(String length) {
		this.length = length;
	}
	public String getHeight() {
		return height;
	}
	public void setHeight(String height) {
		this.height = height;
	}
	
	
}
