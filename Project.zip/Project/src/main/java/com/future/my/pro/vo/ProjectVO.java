package com.future.my.pro.vo;

import com.future.my.common.vo.PagingVO;

public class ProjectVO extends PagingVO{
	private String goodsNO;
	private String goodsCategory;
	private String goodsTitle;
	private String goodsHref;
	private String goodsImg;
	private String goodsPrice;
	private String goodsType;
	private String width;
	private String length;
	private String height;
	private String menuCode;
	private String menuName;
	private String menuParent;
	public ProjectVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "ProjectVO [goodsNO=" + goodsNO + ", goodsCategory=" + goodsCategory + ", goodsTitle=" + goodsTitle
				+ ", goodsHref=" + goodsHref + ", goodsImg=" + goodsImg + ", goodsPrice=" + goodsPrice + ", goodsType="
				+ goodsType + ", width=" + width + ", length=" + length + ", height=" + height + ", menuCode="
				+ menuCode + ", menuName=" + menuName + ", menuParent=" + menuParent + "]";
	}
	public String getGoodsNO() {
		return goodsNO;
	}
	public void setGoodsNO(String goodsNO) {
		this.goodsNO = goodsNO;
	}
	public String getGoodsCategory() {
		return goodsCategory;
	}
	public void setGoodsCategory(String goodsCategory) {
		this.goodsCategory = goodsCategory;
	}
	public String getGoodsTitle() {
		return goodsTitle;
	}
	public void setGoodsTitle(String goodsTitle) {
		this.goodsTitle = goodsTitle;
	}
	public String getGoodsHref() {
		return goodsHref;
	}
	public void setGoodsHref(String goodsHref) {
		this.goodsHref = goodsHref;
	}
	public String getGoodsImg() {
		return goodsImg;
	}
	public void setGoodsImg(String goodsImg) {
		this.goodsImg = goodsImg;
	}
	public String getGoodsPrice() {
		return goodsPrice;
	}
	public void setGoodsPrice(String goodsPrice) {
		this.goodsPrice = goodsPrice;
	}
	public String getGoodsType() {
		return goodsType;
	}
	public void setGoodsType(String goodsType) {
		this.goodsType = goodsType;
	}
	public String getWidth() {
		return width;
	}
	public void setWidth(String width) {
		this.width = width;
	}
	public String getLength() {
		return length;
	}
	public void setLength(String length) {
		this.length = length;
	}
	public String getHeight() {
		return height;
	}
	public void setHeight(String height) {
		this.height = height;
	}
	public String getMenuCode() {
		return menuCode;
	}
	public void setMenuCode(String menuCode) {
		this.menuCode = menuCode;
	}
	public String getMenuName() {
		return menuName;
	}
	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}
	public String getMenuParent() {
		return menuParent;
	}
	public void setMenuParent(String menuParent) {
		this.menuParent = menuParent;
	}
	
	
}
