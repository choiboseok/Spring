package com.future.my.pro.vo;

public class ShoreSearchVO {
	private String shoreNo;
	private String shoreTitle;
	private String shoreHref;
	private String shoreImg;
	private String shorePrice;
	
	public ShoreSearchVO() {
	}
	
	@Override
	public String toString() {
		return "ShoreSearchVO [shoreNo=" + shoreNo + ", shoreTitle=" + shoreTitle + ", shoreHref=" + shoreHref
				+ ", shoreImg=" + shoreImg + ", shorePrice=" + shorePrice + "]";
	}
	
	public String getShoreNo() {
		return shoreNo;
	}
	public void setShoreNo(String shoreNo) {
		this.shoreNo = shoreNo;
	}
	public String getShoreTitle() {
		return shoreTitle;
	}
	public void setShoreTitle(String shoreTitle) {
		this.shoreTitle = shoreTitle;
	}
	public String getShoreHref() {
		return shoreHref;
	}
	public void setShoreHref(String shoreHref) {
		this.shoreHref = shoreHref;
	}
	public String getShoreImg() {
		return shoreImg;
	}
	public void setShoreImg(String shoreImg) {
		this.shoreImg = shoreImg;
	}
	public String getShorePrice() {
		return shorePrice;
	}
	public void setShorePrice(String shorePrice) {
		this.shorePrice = shorePrice;
	}
	
	
}
