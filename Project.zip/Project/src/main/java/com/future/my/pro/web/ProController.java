package com.future.my.pro.web;

import java.lang.reflect.Array;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.future.my.free.vo.FreeBoardSearchVO;
import com.future.my.free.vo.FreeBoardVO;
import com.future.my.pro.service.ProService;
import com.future.my.pro.vo.ProjectVO;

@Controller
public class ProController {
	@Autowired
	ProService proService;
	
	// 메인 페이지
//	@RequestMapping(value = "/")
//	public String home(ProjectVO searchVO, Model model) {
//		
//		return "pro/contentview";
//	}
//	
	//상품출력 출력
	@RequestMapping("/")
	public String contentList(Model model
			              //모델 객체 바인딩 & 뷰 데이터 전달 
			              //요청과 응답시 데이터를 유지하기 위해서 
			             ,@ModelAttribute("searchVO") ProjectVO searchVO ) {
		ArrayList<ProjectVO> contentList = proService.contentList(searchVO);
		model.addAttribute("contentList", contentList);
		ArrayList<ProjectVO> checkboxList = proService.contentList(searchVO);
		model.addAttribute("checkboxList", checkboxList);
		return "pro/contentview";
	}
	
}
